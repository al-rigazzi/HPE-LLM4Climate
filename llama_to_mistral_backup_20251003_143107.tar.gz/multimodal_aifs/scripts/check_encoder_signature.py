# Copyright 2025 Hewlett Packard Enterprise Development LP
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""
AIFS Encoder Signature Analysis

Check the encoder's forward method signature to understand required arguments.
"""

import inspect
import sys
from pathlib import Path

# Add current directory to path for imports
sys.path.append(str(Path(__file__).parent))
sys.path.append("extracted_models")

from load_aifs_encoder import load_aifs_encoder


def analyze_encoder_signature():
    """Analyze the encoder's forward method signature."""
    print("Analyzing AIFS Encoder Signature")
    print("=" * 50)

    # Load encoder
    encoder, _ = load_aifs_encoder()

    # Get forward method signature
    forward_method = encoder.forward
    signature = inspect.signature(forward_method)

    print(f"Encoder Type: {type(encoder).__name__}")
    print("📋 Forward Method Signature:")
    print(f"   {signature}")

    print("\n📌 Parameters:")
    for param_name, param in signature.parameters.items():
        print(
            f"   {param_name}: {param.annotation if param.annotation != inspect.Parameter.empty else 'Any'}"
        )
        if param.default != inspect.Parameter.empty:
            print(f"      Default: {param.default}")

    # Try to find documentation
    if hasattr(encoder, "__doc__") and encoder.__doc__:
        print("\n📚 Documentation:")
        print(f"   {encoder.__doc__}")

    # Check the module
    print(f"\n🏗️ Module: {encoder.__class__.__module__}")
    print(f"File: {inspect.getfile(encoder.__class__)}")

    # Look for example usage in the encoder
    print("\nAvailable Methods:")
    for method_name in dir(encoder):
        if not method_name.startswith("_") and callable(getattr(encoder, method_name)):
            method = getattr(encoder, method_name)
            if hasattr(method, "__doc__") and method.__doc__:
                print(f"   {method_name}: {method.__doc__.split('.')[0]}")
            else:
                print(f"   {method_name}")


if __name__ == "__main__":
    analyze_encoder_signature()
